class InvalidUrl(Exception):
    pass